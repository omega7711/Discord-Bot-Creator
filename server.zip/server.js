const express = require('express');
const open = require('open');
const app = express();

app.use('/api/discord', require('./api/discord'));

const { CLIENT_ID, CLIENT_SECRET, redirect } = require('./config.json');

app.get('/', (req, res) => {
  res.redirect(`https://discord.com/oauth2/authorize?response_type=code&client_id=${CLIENT_ID}&scope=identify%20guilds%20email&state=15773059ghq9183habn&redirect_uri=${redirect}&prompt=consent`);
});

app.listen(2604, () => {
    console.info('Running on port 2604');
    open('http://127.0.0.1:2604')
});

app.use((err, req, res, next) => {
  switch (err.message) {
    case 'NoCodeProvided':
      return res.status(400).send({
        status: 'ERROR',
        error: err.message,
      });
    default:
      return res.status(500).send({
        status: 'ERROR',
        error: err.message,
      });
  }
});