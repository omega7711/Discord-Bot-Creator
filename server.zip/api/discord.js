const DiscordOauth2 = require("discord-oauth2");
const oauth = new DiscordOauth2();
const express = require('express');
const fs = require('fs');
const os = require('os');


const router = express.Router();

const { CLIENT_ID, CLIENT_SECRET, redirect } = require('../config.json');

router.get('/login', (req, res) => {
  res.redirect(`https://discord.com/oauth2/authorize?response_type=code&client_id=${CLIENT_ID}&scope=identify%20guilds.join&state=15773059ghq9183habn&redirect_uri=${redirect}&prompt=consent`);
});

router.get('/kill', (req, res) => {
  res.redirect('https://discord.com/oauth2/authorized')
  process.exit();
})

router.get('/callback', (req, res) => {
  oauth.tokenRequest({
    clientId: CLIENT_ID,
    clientSecret: CLIENT_SECRET,
    version: "v8",
    code:  req.query.code,
    scope: "identify guilds email",
    grantType: "authorization_code",
    
    redirectUri: "http://localhost:2604/api/discord/callback",
  }).then(access => {
      oauth.getUser(access.access_token).then(user => {
        const filepath = os.homedir() + "/AppData/Roaming/DiscordBC/user/"
        fs.writeFile(filepath + "username.dbcu", user.username, function (err) {
          if (err) return console.log(err);
          console.log('username enregistré!');
        });
        fs.writeFile(filepath + "id.dbcu", user.id, function (err) {
          if (err) return console.log(err);
          console.log('id enregistré!');
        });
        fs.writeFile(filepath + "avatar.dbcu", `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=4096&ignore=true`, function (err) {
          if (err) return console.log(err);
          console.log('avatar enregistré!');
        });
        fs.writeFile(filepath + "registered.dbcu", "true", function (err) {
          if (err) return console.log(err);
          console.log('enregistrement enregistré!');
        });
      });
  })
  setTimeout(function () {res.redirect("http://localhost:2604/api/discord/kill")}, 1000) 
})

module.exports = router;
